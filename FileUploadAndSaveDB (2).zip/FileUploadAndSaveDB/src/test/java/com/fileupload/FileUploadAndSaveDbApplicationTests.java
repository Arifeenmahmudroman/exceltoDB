package com.fileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileUploadAndSaveDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
