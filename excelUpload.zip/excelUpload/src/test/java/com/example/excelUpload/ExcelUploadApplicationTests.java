package com.example.excelUpload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
