package com.example.excelUpload.controller;


import com.example.excelUpload.entitymodel.Product;
import com.example.excelUpload.helper.Helper;
import com.example.excelUpload.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin("*")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("product/upload")
    public ResponseEntity<?> upload(@RequestParam("file")MultipartFile file) {
        if(Helper.checkExcelFormat(file)) {
            //true
            this.productService.save(file);

//            return ResponseEntity.ok(Map.of("Message","file is puloaded data is save to db"));
            return ResponseEntity.ok(Map.of("message","File Uploaded and saved to db"));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("please Upload Excel File Only");

    }

    @GetMapping("/product")
    public List<Product> getAllProduct(){
        return this.productService.getAllProducts();
    }
}
