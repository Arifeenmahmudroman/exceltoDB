package com.example.excelUpload.repo;

import com.example.excelUpload.entitymodel.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepo extends JpaRepository<Product, Integer> {
}
